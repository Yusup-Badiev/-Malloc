#include "mymalloc.h"

static char myblock[4096];

int abs(int num){
	if(num < 0) return (-1)*num;
	return num;
}

int changeCharsToNum(char c1, char c2){     //takes metadate and turn it into amount of bytes free or malloced, return negative if malloced posative if free
        int mall = 0;
        if(c1 >= 50){
                mall = 1;
                c1 -= 50;
        }

        int test = 0;
        test += (int) c2;
        if(c2 < 0){
                test = 127 + (~test)+1;
        }

        int num1 = c1 << 8;
        test += num1;

        if(mall) return (-1)*test;
        return test;
}

void dignosti(){                          // prints out full array
        int i = 2;
        printf("\n\n\n");
        while(i < 4095){
                int add = changeCharsToNum(myblock[i], myblock[i+1]);
                printf("%d === ", add);
                i += 2 + abs(add);
        }
}

int isFirstRun(){                         // test if first run for magic number
	if(myblock[0] == -20 && myblock[1] == -20) return 0;
	return 1;
}

void setupFirstRun(){                     // if first run sets up metadata
	myblock[0] = -20;
        myblock[1] = -20;
        myblock[2] = 15;
        myblock[3] = -125;
}

void labelMaker(int address, int num, int free){      // puts defiend metadata in defined address
	myblock[address] = num >> 8;
	if(!free) myblock[address] += 50;
	char c2;
	num = num&255;
	if(num > 127){
		c2 = -1*(num - 127);
	}
	else{
		c2 = num;
	}
	myblock[address + 1] = c2; 
}

int isFree(int address){                            // tests if address is free or malloced
	if(myblock[address] >= 50) return 0;
	return 1;
}

int validPtr(int address){                           // tests if pointer is ar head of metdata
	int i = 2;

        while(i < 4095){
                int add = changeCharsToNum(myblock[i], myblock[i+1]);
		
		//printf("test : %d \n", i+2);
		
                if(i+2 == address && myblock[i] >= 50) return 1;
		
                i += 2 + abs(add);
        }
	
	return 0;
}

void compressFree(){                                  // merges free blocks
	int i = 2;
	int prev = 0;


        while(i < 4095){
                int add = changeCharsToNum(myblock[i], myblock[i+1]);
		
		if(myblock[i] < 50 && prev && myblock[prev] < 50){
			labelMaker(prev, abs(changeCharsToNum(myblock[i], myblock[i+1])) + abs(changeCharsToNum(myblock[prev], myblock[prev+1])) + 2, 1);
			break;
		}
		
		prev = i;
                i += 2 + abs(add);
        }

	i = 2;
	prev = 0;

	while(i < 4095){
                int add = changeCharsToNum(myblock[i], myblock[i+1]);

                if(myblock[i] < 50 && prev && myblock[prev] < 50){
                        labelMaker(prev, abs(changeCharsToNum(myblock[i], myblock[i+1])) + abs(changeCharsToNum(myblock[prev], myblock[prev+1])) + 2, 1);
                        break;
                }

                prev = i;
                i += 2 + abs(add);
        }
}

int findIndexOfFree(int size){               // finds free data large enough for malloc asked size
	int i = 2;
	
	while(i < 4095){
		int add = changeCharsToNum(myblock[i], myblock[i+1]);
		
		//printf("%d and %d\n", add, size);
		
		if(add == size ||( add > 0 && add >= size + 2) ) return i;
		i += 2 + abs(add);
	}
	return 0;
}

void* mymalloc(int bytesWanted, char* file, int line){                     // mallocs amoount of blocks asked for
	if(bytesWanted < 1) {
		printf("Error: file: %s line: %d\n\t block wanted less then 1\n\n", file, line);
		return NULL;
	}
	
	if(isFirstRun()) {
		setupFirstRun();
	}
	
	int index = findIndexOfFree(bytesWanted);
	
	//printf("%d\n", index);
	
	if(!index) {
		printf("Error: file: %s line: %d\n\t Not enough free memory\n\n", file, line);
		return NULL;
	}
	
	int size = changeCharsToNum(myblock[index], myblock[index+1]);
	
	//dignosti();
	if(size == bytesWanted){
		labelMaker(index, size, 0);
		return &myblock[index + 2];
	}
	
	labelMaker(index, bytesWanted, 0);
	labelMaker(index + 2 + bytesWanted, size - 2 - bytesWanted, 1);
	return &myblock[index + 2];
}

void myfree(void* addresss, char* file, int line){                     //frees ponter
	if(addresss == NULL) {
                printf("Error: file: %s line: %d\n\t Null pointer\n\n", file, line);
                return;
        }

	int address = addressToIndex(addresss);
	
	//printf("a %d", address);
	
	if(isFirstRun()) {
		printf("Error: file: %s line: %d\n\t No Malloced data\n\n", file, line);
		return;
	}
	
	if(!address || !validPtr(address)){
		printf("Error: file: %s line: %d\n\t Not valid address pointer\n\n", file, line);
		return;
	}
	
	myblock[address - 2] = myblock[address - 2] - 50;
	
	compressFree();
	//dignosti();
}

int addressToIndex(void* ptr){                                 // turns address to index in array
	int i = 2;
	for(i = 2; i < 4096; i++){
		if(&myblock[i] == ptr){
			return i;
		}
	}
	return 0;
}
