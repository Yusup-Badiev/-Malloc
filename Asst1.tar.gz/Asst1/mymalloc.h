#ifndef _malloc_h
#define _malloc_h

#include <stdio.h>
#include <stdlib.h> 
#include <time.h>

#define malloc(x) mymalloc(x, __FILE__, __LINE__)
#define free(x) myfree(x, __FILE__, __LINE__)

void* mymalloc(int bytesWanted, char* file, int line);
void myfree(void* address, char* file, int line);

#endif
