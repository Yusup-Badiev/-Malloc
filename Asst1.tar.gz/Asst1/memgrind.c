#include "mymalloc.h"

double testA(){
	struct timeval start, end;
	gettimeofday(&start, NULL);

	int i = 0;
	for(i = 0; i < 150; i++){
		char* p = (char*)malloc(1);
		free(p);
	}

	gettimeofday(&end, NULL);
	return ((double)((end.tv_sec * 1000000 + end.tv_usec) - (start.tv_sec * 1000000 + start.tv_usec)));
}

double testB(){
	struct timeval start, end;
        gettimeofday(&start, NULL);

	char* ptrs[50];
	int i = 3;
	while(i--){
		int j = 0;
		for(j = 0; j < 50; j++){
			ptrs[j] = (char*)malloc(1);
		}
		for(j = 0; j < 50; j++){
                        free(ptrs[j]);
                }
	}

	gettimeofday(&end, NULL);
        return ((double)((end.tv_sec * 1000000 + end.tv_usec) - (start.tv_sec * 1000000 + start.tv_usec)));
}

double testC(){
	struct timeval start, end;
        gettimeofday(&start, NULL);

	char* ptrs[50];
	int totalMall = 0;
	int currMall = 0;
	while(totalMall != 50){
		if(!currMall){
			ptrs[currMall++] = malloc(1);
			totalMall++;
			continue;
		}
		int F = rand()%2;
		if(F){
			int FR = rand()%currMall;
                        currMall--;
                        free(ptrs[FR]);
                        int i = FR;
                        for(i = FR; i <= currMall; i++){
                                ptrs[i] = ptrs[i+1];
                        }
		}
		else{
			ptrs[currMall++] = malloc(1);
                        totalMall++;
		}
	}
	int i;

	for(i = 0; i < currMall; i++){
		free(ptrs[i]);
	}

	gettimeofday(&end, NULL);
        return ((double)((end.tv_sec * 1000000 + end.tv_usec) - (start.tv_sec * 1000000 + start.tv_usec)));
}

double testD(){
	struct timeval start, end;
        gettimeofday(&start, NULL);

	char* ptrs[50];
        int totalMall = 0;
        int currMall = 0;
        while(totalMall != 50){
                if(!currMall){
                        ptrs[currMall++] = malloc(rand()%64+1);
                        totalMall++;
                        continue;
                }
                int F = rand()%2;
                if(F){
			int FR = rand()%currMall;
                        currMall--;
                        free(ptrs[FR]);
			int i = FR;
			for(i = FR; i <= currMall; i++){
				ptrs[i] = ptrs[i+1];
			}
                }
                else{
                        ptrs[currMall++] = malloc(rand()%64+1);
                        totalMall++;
                }
        }
        int i;

        for(i = 0; i < currMall; i++){
                free(ptrs[i]);
        }

	gettimeofday(&end, NULL);
        return ((double)((end.tv_sec * 1000000 + end.tv_usec) - (start.tv_sec * 1000000 + start.tv_usec)));
}

double testE(){
	struct timeval start, end;
        gettimeofday(&start, NULL);

	char* ptrs[50];
        int totalMall = 0;
        int currMall = 0;
        while(totalMall != 50){
                if(!currMall){
                        ptrs[currMall++] = malloc(rand()%6000+1);
                        totalMall++;
                        continue;
                }
                int F = rand()%2;
                if(F){
                        int FR = rand()%currMall;
                        currMall--;
                        free(ptrs[FR]);
                        int i = FR;
                        for(i = FR; i <= currMall; i++){
                                ptrs[i] = ptrs[i+1];
                        }
                }
                else{
                        ptrs[currMall++] = malloc(rand()%6000+1);
                        totalMall++;
                }
        }
        int i;

        for(i = 0; i < currMall; i++){
                free(ptrs[i]);
        }

	gettimeofday(&end, NULL);
        return ((double)((end.tv_sec * 1000000 + end.tv_usec) - (start.tv_sec * 1000000 + start.tv_usec)));
}

double testF(){
	struct timeval start, end;
        gettimeofday(&start, NULL);

	char* ptrs[50];
        int totalMall = 0;
        int currMall = 0;
        while(totalMall != 50){
                if(!currMall){
                        ptrs[currMall++] = malloc(rand()%64+1);
                        totalMall++;
                        continue;
                }
                int F = rand()%2;
                if(F){
                        int FR = rand()%currMall;
                        currMall--;
                        free(ptrs[FR]);
                        int i = FR;
                        for(i = FR; i <= currMall; i++){
                                ptrs[i] = ptrs[i+1];
                        }
                }
                else{
                        ptrs[currMall++] = malloc(rand()%64+1);
                        totalMall++;
			free(rand()%6000+1);
                }
        }
        int i;

        for(i = 0; i < currMall; i++){
                free(ptrs[i]);
        }

	gettimeofday(&end, NULL);
        return ((double)((end.tv_sec * 1000000 + end.tv_usec) - (start.tv_sec * 1000000 + start.tv_usec)));
}

int main(int argc, char* argv){
	double sumA = 0;
	double sumB = 0;
	double sumC = 0;
	double sumD = 0;
	double sumE = 0;
        double sumF = 0;

	int i;
	for(i = 0; i < 100; i++){
		sumA += testA();
        	sumB += testB();
        	sumC += testC();
        	sumD += testD();
		sumE += testE();
                sumF += testF();
	}

	sumA = sumA/100;
       	sumB = sumB/100;
        sumC = sumC/100;
       	sumD = sumD/100;
	sumE = sumE/100;
        sumF = sumF/100;

	printf("\n\n\n\n\n %f %f %f %f %f", sumA, sumB, sumC, sumD, sumE, sumF);
}
